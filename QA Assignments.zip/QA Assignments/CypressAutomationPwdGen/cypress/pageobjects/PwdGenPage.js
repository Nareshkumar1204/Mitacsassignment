export default class PwdGenPage {
    getPwdGenLink() {
        return cy.get("a[data-gaeventaction='hero_use-generator']")

    }


    getPwdLength() {
        return cy.get("input#lp-pg-password-length")

    }

    getPwdType() {
        return cy.get("label.lp-radio__label")

    }

    getPwdContent() {
        return cy.get("label.lp-checkbox__label")

    }

    copyPwd()
    {
        return cy.get("button[class*='lp-pg-copy-password']")
    }

    generatedPwd()
    {
        return cy.get("input#GENERATED-PASSWORD")
    }

    pwdLabel()
    {
        return cy.get("h3.lp-pg-settings__title")
    }

}