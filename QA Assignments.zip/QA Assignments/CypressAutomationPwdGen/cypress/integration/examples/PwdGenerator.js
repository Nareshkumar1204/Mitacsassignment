
import PwdGenPage from '../../pageobjects/PwdGenPage'

let rowsLenght = 0
let pwdPage = new PwdGenPage()

describe('Pwd generation data setup', () =>{

  before(() =>{
        cy.task('readXlsx', { file: 'cypress/fixtures/uploader.xlsx', sheet: "Sheet1" }).then(function(rows){
            rowsLenght = rows.length;
            cy.log(this.rowsLength)
            cy.writeFile("cypress/fixtures/xlsxData.json", { rows })
            })
    })

  it('Password generation with various combinations', ()=> {
            cy.visit(Cypress.env("baseUrl")) 
            cy.fixture('xlsxData').then((data) => {
              for (let i = 0; i < rowsLenght; i++) {
                pwdPage.getPwdGenLink().click()
                cy.wait(1000)
                pwdPage.getPwdLength().clear()  
                pwdPage.getPwdLength().type(data.rows[i].PwdLength)
                cy.selectPwdData(data.rows[i].PwdType,pwdPage.getPwdType())
                cy.selectPwdData(data.rows[i].PwdContent,pwdPage.getPwdContent())
                pwdPage.pwdLabel().click()
                cy.wait(2000)
                pwdPage.generatedPwd().invoke('val').then((pwd)=>
                {
                  cy.log("Generated password is: "+pwd)
                  cy.task('writeXlsx', { file: 'cypress/fixtures/uploader.xlsx', sheet: "Sheet1", cell:'D'+(i+2),value:pwd })              
                  }
                )
              }
            })
          })
})
      
    