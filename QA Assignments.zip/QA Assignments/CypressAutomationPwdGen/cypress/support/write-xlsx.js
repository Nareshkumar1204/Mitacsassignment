
const fs = require('fs');
const XLSX = require('xlsx');

const write = ({file, sheet, cell, value}) => {
   const buf = fs.readFileSync(file);
   const workbook = XLSX.read(buf, { type: 'buffer' });
   const worksheet = workbook.Sheets[sheet];
   worksheet[cell] = { t: 's', v: value }; // 's' for string
   XLSX.writeFile(workbook, file);
   return null
}

module.exports = {
   write
}