const { defineConfig } = require("cypress");
const readXlsx = require('./cypress/support/read-xlsx')
const writeXlsx = require('./cypress/support/write-xlsx')

module.exports = defineConfig({
  env: {
    baseUrl: 'https://wwww.lastpass.com/features/password-generator'
    
  },
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here      
        on('task', {
          'readXlsx': readXlsx.read,
          'writeXlsx': writeXlsx.write
        })
      },
    specPattern: 'cypress/integration/examples/*.js'

  },
  video: true
});
